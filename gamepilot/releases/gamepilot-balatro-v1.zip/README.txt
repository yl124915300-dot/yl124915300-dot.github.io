GamePilot Balatro Hand Coach v1.0.0
Open index.html in a modern browser or upload this ZIP as an HTML project to itch.io.
No dependencies, API keys or game files. The demo is synthetic, not player validation.
Screenshot AI is BLOCKED. Image control is preview only.
Free, no checkout or payout system. AI-assisted development; original code and interface; unofficial.
Browser interaction/current-build game reproduction unverified by preparing agent.
